<?php include 'header.php'; ?>

    <main>
        <section class="home-intro">
            
            <div class="intro-text">

            <h1>Department of Zoology</h1>
            <p>Inspiring scientific curiosity <br> and hands-on learning since 1958.</p>
            
            </div>

            <div class="intro-image">
                <img src="content/gecko.jpg" alt="gecko">
            </div>

        </section>

    </main>

<?php include 'footer1.php'; ?>