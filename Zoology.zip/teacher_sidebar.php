<head>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<aside class="admin-sidebar">
    <nav>
        <ul>
            <li><a href="teacher_dashboard.php">Dashboard</a></li>
            <li><a href="manage_attendance.php">Manage Attendance</a></li>
            <li><a href="manage_resources.php">Manage Resources</a></li>
            <li><a href="teacher_settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</aside>