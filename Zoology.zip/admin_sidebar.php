<head>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<aside class="admin-sidebar">
    <nav>
        <ul>
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="manage_students.php">Manage Students</a></li>
            <li><a href="manage_teachers.php">Manage Teachers</a></li>
            <li><a href="manage_notices.php">Manage Notices</a></li>
            <li><a href="manage_courses.php">Manage Courses</a></li>
            <li><a href="manage_contact.php">Manage Contact</a></li>
            <li><a href="admin_settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</aside>